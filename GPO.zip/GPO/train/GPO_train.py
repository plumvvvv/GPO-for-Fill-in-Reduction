import argparse
from pathlib import Path

import networkx as nx

import torch
import torch.nn as nn

from torch_geometric.data import Data, DataLoader, Batch
from torch_geometric.nn import SAGEConv, graclus, avg_pool, global_mean_pool, MixHopConv
from torch_geometric.utils import to_networkx, k_hop_subgraph, degree, remove_self_loops

import numpy as np
from numpy import random

from scipy.sparse import coo_matrix, rand
from scipy.io import mmread, mmwrite
from scipy.spatial import Delaunay

import timeit
import os
from itertools import combinations
import wandb

#Generate Delaunay dataset
def delaunay_dataset_with_coarser(n, n_min, n_max):
    dataset = []
    while len(dataset) < n:
        number_nodes = np.random.choice(np.arange(n_min, n_max + 1, 2))
        g = random_delaunay_graph(number_nodes)
        dataset.append(g)
        while g.num_nodes > 200:
            cluster = graclus(g.edge_index)
            coarse_graph = avg_pool(
                cluster,
                Batch(
                    batch=torch.zeros(
                        g.num_nodes),
                    x=g.x,
                    edge_index=g.edge_index))
            g1 = Data(x=coarse_graph.x, edge_index=coarse_graph.edge_index)
            dataset.append(g1)
            g = g1

    loader = DataLoader(dataset, batch_size=1, shuffle=True)
    return loader

# Networkx geometric Delaunay mesh with n random points in the unit square
def graph_delaunay_from_points(points):
    mesh = Delaunay(points, qhull_options="QJ")
    mesh_simp = mesh.simplices
    edges = []
    for i in range(len(mesh_simp)):
        edges += combinations(mesh_simp[i], 2)
    e = list(set(edges))
    return nx.Graph(e)

# Pytorch geometric Delaunay mesh with n random points in the unit square
def random_delaunay_graph(n):
    points = np.random.random_sample((n, 2))
    g = graph_delaunay_from_points(points)
    
    adj_sparse = nx.to_scipy_sparse_array(g, format='coo')
    row = adj_sparse.row
    col = adj_sparse.col

    one_hot = []
    for i in range(g.number_of_nodes()):
        one_hot.append([1., 0., 0.])

    edges = torch.tensor([row, col], dtype=torch.long)
    nodes = torch.tensor(np.array(one_hot), dtype=torch.float)
    graph_torch = Data(x=nodes, edge_index=edges)
    
    return graph_torch

# Converts a sparse adjacency matrix into a PyTorch geometric graph data object.
def torch_from_sparse(adj_sparse):

    row = adj_sparse.row
    col = adj_sparse.col

    features = []
    for i in range(adj_sparse.shape[0]):
        features.append([1., 0.])

    edges = torch.tensor([row, col], dtype=torch.long)
    nodes = torch.tensor(np.array(features), dtype=torch.float)
    graph_torch = Data(x=nodes, edge_index=edges)

    return graph_torch


# Load the training set from the traindata directory
def load_traindata(traindata,ns,m):
    files = os.listdir(traindata)
    selected_files = files[ns: ns+m]
    name, dataset = [], []
    for graph in selected_files:
        matrix_sparse = mmread(os.path.join(traindata,str(graph)))
        g = torch_from_sparse(matrix_sparse)
        g.weight = torch.tensor([1] * g.num_edges)
        dataset.append(g)
        name.append(str(graph))
    loader = DataLoader(dataset, batch_size=1, shuffle=True)
    return loader, name
        
        
#vertex elimination process
def remove_vertex(state, vertex, device):
    nnzadd = 0

     # Get the degree information of the original state
    original_degrees = state.x[:, 1].clone()

    # Get the neighbors of the vertex
    neighbors = state.edge_index[1, state.edge_index[0] == vertex]

     # Remove edges associated with the vertex
    mask = (state.edge_index[0] != vertex) & (state.edge_index[1] != vertex)
    new_edge_index = state.edge_index[:, mask]
    edge_set = set(map(tuple, new_edge_index.t().tolist()))

    # Add edges between non-adjacent neighbors
    non_neighbors = torch.combinations(neighbors, 2)
    for nn in non_neighbors:
        if (nn[0].item(), nn[1].item()) not in edge_set and (nn[1].item(), nn[0].item()) not in edge_set:
            new_edge = torch.stack([nn, nn.flip(0)], dim=1)
            new_edge_index = torch.cat([new_edge_index, new_edge], dim=1)
            original_degrees[nn] += 1
            nnzadd += 1
            edge_set.update({(nn[0].item(), nn[1].item()), (nn[1].item(), nn[0].item())})

    original_degrees[neighbors] -= 1

    # Update the features of nodes in the affected area
    all_neighbors = set(neighbors.tolist())
    for neighbor in neighbors:
        neighbors_of_neighbor = state.edge_index[1, state.edge_index[0] == neighbor]
        all_neighbors.update(neighbors_of_neighbor.tolist())

    for i in all_neighbors:
        ineighbors = state.edge_index[0] == i
        neighbor_indices = state.edge_index[1][ineighbors]
        neighbor_degrees_sum = original_degrees[neighbor_indices].sum().item() - len(neighbor_indices)
        synergy = (original_degrees[i].item() - 1) * neighbor_degrees_sum
        state.x[i, 0] = synergy

    # Remove the vertex node's attributes and degree information
    new_x = torch.cat([state.x[:vertex], state.x[vertex + 1:]], dim=0)
    new_degrees = torch.cat([original_degrees[:vertex], original_degrees[vertex + 1:]], dim=0)
    
    # Update node indices to account for the removed vertex
    new_edge_index -= (new_edge_index > vertex).type_as(new_edge_index)

    # Create a new x matrix to store each node's label and degree
    new_x = torch.stack([new_x[:, 0], new_degrees, new_x[:, 2]], dim=1).float()

    # Return the new graph
    new_state = Batch(batch=torch.zeros(new_x.shape[0], dtype=torch.long, device=device), x=new_x, edge_index=new_edge_index)

    return new_state, nnzadd


# Training loop
def training_loop(
        model,
        training_dataset,
        epoch,
        gamma,
        optimizer_actor,
        optimizer_critic,
        print_loss,
        device,
        scheduler_actor,
        scheduler_critic):


    for i in range(epoch):
        print('epoch:',i)
        p = 0
        ntimes_critic = 0
        for graph in training_dataset:
            rew_partial = 0
            graph.edge_index, _ = remove_self_loops(graph.edge_index)

            # Get node features
            Feature = []
            # Get node degrees
            degs = degree(graph.edge_index[0], num_nodes=graph.x.size(0), dtype=torch.uint8)
            for j in range(graph.num_nodes):
                node_degree_minus_one = degs[j].item() - 1
                neighbors = graph.edge_index[0] == j
                neighbor_indices = graph.edge_index[1][neighbors]
                neighbor_degrees_sum = degs[neighbor_indices].sum().item() - len(neighbor_indices)
                # Calculate synergy
                synergy = node_degree_minus_one * neighbor_degrees_sum
                Feature.append([synergy, degs[j],j])

            graph.x = torch.tensor(np.array(Feature), dtype=torch.float).to(device)
            start = Batch(batch=torch.zeros(graph.num_nodes, dtype=torch.long, device=device), x=graph.x, edge_index=(graph.edge_index).to(device))
            
            len_episode = graph.num_nodes
            
            time = 0
            rews, vals, logprobs, order, nnz = [], [], [], [], []

            while time < len_episode-1:
                # Model prediction
                policy, values = model(start)
                probs = policy.view(-1)

                action = torch.distributions.Categorical(
                    logits=probs).sample().detach().item()
                
                # Graph update after elimination
                new_state, rew = remove_vertex(start, action, device)
                rew_partial += rew

                logprobs.append(policy.view(-1)[action])

                vals.append(values)
                nnz.append(start.num_edges)

                rews.append(rew)
                order.append(int(start.x[action][2]))
                start = new_state

                del new_state

                time += 1

                # After len_episode we update the loss
                if time == len_episode - 1:
                    logprobs = torch.stack(logprobs).flip(dims=(0,)).view(-1)
                    vals = torch.stack(vals).flip(dims=(0,)).view(-1)
                    rews = torch.tensor(rews).flip(dims=(0,)).view(-1)
                    nnz = torch.tensor(nnz).flip(dims=(0,)).view(-1)

                    # Compute the cumulative rewards
                    R = []
                    R_partial = torch.tensor([0.])
                    for j in range(rews.shape[0]):
                        R_partial = rews[j] + gamma * R_partial
                        R.append(R_partial)

                    # Adaptive Saturation Return
                    R = ((1e-10 + nnz - torch.stack(R).view(-1))/(1e-10 + nnz + torch.stack(R).view(-1))).to(device)
                    # Basic Normalized Return
                    # R = -R/(len_episode*len_episode)
                   
                    # Compute the advantage
                    advantage = R - vals.detach()

                    # Actor loss
                    actor_loss = torch.mean(-1 * logprobs * advantage)

                    # Critic loss
                    critic_loss = torch.mean(torch.pow(R - vals, 2))

                    
                    optimizer_critic.zero_grad()
                    critic_loss.backward()
                    optimizer_critic.step()
                    ntimes_critic += 1

                    if ntimes_critic % 2 == 0:
                        optimizer_actor.zero_grad()
                        actor_loss.backward()
                        optimizer_actor.step()
                        ntimes_critic += 1    

                    rews, vals, logprobs = [], [], []


            if (p + 1) % 1000 == 0:
                torch.save(model.state_dict(), outdir + '/model_reoder_'+str(i)+'_p_'+str(p))
            p += 1
        scheduler_actor.step()
        scheduler_critic.step()

    return model


#Model with SAGEConv
class ModelSage(torch.nn.Module):
    def __init__(self, input, units):
        super(ModelSage, self).__init__()

        self.input = input
        self.units = units
        self.critic_layers = 2
        self.actor_layers = 2
        self.activation = torch.tanh

        self.conv_first_actor = SAGEConv(self.input, self.units)
        self.conv_first_critic = SAGEConv(self.input, self.units)

        self.conv_actor = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.actor_layers)]
        )
        self.conv_critic = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.critic_layers)]
        )
        self.final_critic = nn.Linear(self.units, 1)
        self.final_actor = nn.Linear(self.units, 1)

    def forward(self, graph):
        #Normalize node features
        x = torch.cat((graph.x[:, 0:1] / (graph.num_nodes*graph.num_nodes), graph.x[:, 1:2] / graph.num_nodes), dim=1)
        edge_index, batch = graph.edge_index, graph.batch

        x_actor = self.activation(self.conv_first_actor(x, edge_index))

        for i in range(self.actor_layers):
            x_actor = self.conv_actor[i](x_actor, edge_index)
            if i < self.actor_layers - 1:
                x_actor = self.activation(x_actor)
        x_actor = self.final_actor(x_actor)  
        x_actor = torch.log_softmax(x_actor, dim=0)
        

        if not self.training:
            return x_actor

        x_critic = self.activation(self.conv_first_critic(x, edge_index))
        for i in range(self.critic_layers):
            x_critic = self.conv_critic[i](x_critic, edge_index)
            if i < self.critic_layers - 1:
                x_critic = self.activation(x_critic)
        x_critic = self.final_critic(x_critic)
        x_critic = torch.tanh(global_mean_pool(x_critic, batch))
        return x_actor, x_critic

#Model with MixHopConv
class ModelMixHop(torch.nn.Module):
    def __init__(self, input, hidden, output, powers):
        super(ModelMixHop, self).__init__()

        self.input = input
        self.hidden = hidden
        self.output = output
        self.critic_layers = 2
        self.actor_layers = 2
        self.activation = torch.tanh
        self.powers = powers

        self.conv_first_actor = MixHopConv(self.input, self.hidden, self.powers)
        self.conv_first_critic = MixHopConv(self.input, self.hidden, self.powers)

        self.conv_actor = nn.ModuleList(
            [MixHopConv(len(powers)*self.hidden, self.hidden, self.powers)
             for i in range(self.actor_layers)]
        )
        self.conv_critic = nn.ModuleList(
            [MixHopConv(len(powers)*self.hidden, self.hidden, self.powers)
             for i in range(self.critic_layers)]
        )
        self.final_critic = nn.Linear(len(powers)*self.hidden, 1)
        self.final_actor = nn.Linear(len(powers)*self.hidden, 1)

    def forward(self, graph):
        #Normalize node features
        x = torch.cat((graph.x[:, 0:1] / (graph.num_nodes*graph.num_nodes), graph.x[:, 1:2] / graph.num_nodes), dim=1)
        edge_index, batch = graph.edge_index, graph.batch

        x_actor = self.activation(self.conv_first_actor(x, edge_index))

        for i in range(self.actor_layers):
            x_actor = self.conv_actor[i](x_actor, edge_index)
            if i < self.actor_layers - 1:
                x_actor = self.activation(x_actor)
        x_actor = self.final_actor(x_actor)  
        x_actor = torch.log_softmax(x_actor, dim=0)
        

        if not self.training:
            return x_actor

        x_critic = self.activation(self.conv_first_critic(x, edge_index))
        for i in range(self.critic_layers):
            x_critic = self.conv_critic[i](x_critic, edge_index)
            if i < self.critic_layers - 1:
                x_critic = self.activation(x_critic)
        x_critic = self.final_critic(x_critic)
        x_critic = torch.tanh(global_mean_pool(x_critic, batch))
        return x_actor, x_critic

#Model DRL_GE same as DRL_ND
class ModelDRLGE(torch.nn.Module):
    def __init__(self, units):
        super(ModelSage, self).__init__()

        self.units = units
        self.common_layers = 2
        self.critic_layers = 1
        self.actor_layers = 1
        self.activation = torch.tanh

        self.conv_first = SAGEConv(2, self.units)
        self.conv_common = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.common_layers)]
        )
        self.conv_actor = nn.ModuleList(
            [SAGEConv(self.units,
                      1 if i == self.actor_layers - 1 else self.units)
             for i in range(self.actor_layers)]
        )
        self.conv_critic = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.critic_layers)]
        )
        self.final_critic = nn.Linear(self.units, 1)

    def forward(self, graph):
        #Normalize node features
        x = torch.cat((graph.x[:, 0:1] / (graph.num_nodes*graph.num_nodes), graph.x[:, 1:2] / graph.num_nodes), dim=1)
        edge_index, batch = graph.edge_index, graph.batch

        x = self.activation(self.conv_first(x, edge_index))
        for i in range(self.common_layers):
            x = self.activation(self.conv_common[i](x, edge_index))

        x_actor = x
        for i in range(self.actor_layers):
            x_actor = self.conv_actor[i](x_actor, edge_index)
            if i < self.actor_layers - 1:
                x_actor = self.activation(x_actor)
        x_actor = torch.log_softmax(x_actor, dim=0)
        

        if not self.training:
            return x_actor

        x_critic = x.detach()
        for i in range(self.critic_layers):
            x_critic = self.conv_critic[i](x_critic, edge_index)
            if i < self.critic_layers - 1:
                x_critic = self.activation(x_critic)
        x_critic = self.final_critic(x_critic)
        x_critic = torch.tanh(global_mean_pool(x_critic, batch))
        return x_actor, x_critic


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--out', default='../modelout', type=str)
    parser.add_argument(
        "--nmin",
        default=60,
        help="Minimum graph size",
        type=int)
    parser.add_argument(
        "--nmax",
        default=200,
        help="Maximum graph size",
        type=int)
    parser.add_argument(
        "--ntrain",
        default=10000,
        help="Number of training graphs",
        type=int)
    parser.add_argument(
        "--epochs",
        default=20,
        help="Number of training epochs",
        type=int)
    parser.add_argument(
        "--print_rew",
        default=20,
        help="Steps to take before printing the reward",
        type=int)
    parser.add_argument(
        "--lr",
        default=0.01,
        help="Learning rate",
        type=float)
    parser.add_argument(
        "--gamma",
        default=1,
        help="Gamma, discount factor",
        type=float)
    parser.add_argument(
        "--units",
        default=16,
        help="Number of units in conv layers",
        type=int)

    torch.manual_seed(42)
    np.random.seed(42)
    random.seed(42)

    args = parser.parse_args()
    outdir = args.out
    Path(outdir).mkdir(parents=True, exist_ok=True)

    n_min = args.nmin
    n_max = args.nmax
    n_train = args.ntrain
    epoch = args.epochs
    print_loss = args.print_rew

    lr = args.lr
    gamma = args.gamma
    units = args.units


    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    t0 = timeit.default_timer()

    dataset = delaunay_dataset_with_coarser(n_train, n_min, n_max)

    loadtime = timeit.default_timer() - t0
    print("loadtime:",loadtime)

    # model = ModelSage(units)
    # model = ModelDRLGE(units)
    model = ModelMixHop(2,units,units,[0,1,2])
    model.to(device)
    model.share_memory()

    print(model)


    actor_params = list(model.conv_first_actor.parameters()) + \
               list(model.conv_actor.parameters()) + \
               list(model.final_actor.parameters())

    critic_params = list(model.conv_first_critic.parameters()) + \
                list(model.conv_critic.parameters()) + \
                list(model.final_critic.parameters())

    actorlr = lr
    criticlr = lr
    optimizer_actor = torch.optim.Adam(actor_params, lr=actorlr)
    optimizer_critic = torch.optim.Adam(critic_params, lr=criticlr)
    scheduler_actor = torch.optim.lr_scheduler.MultiStepLR(optimizer_actor, milestones=[0, 3, 5], gamma=0.1)
    scheduler_critic = torch.optim.lr_scheduler.MultiStepLR(optimizer_critic, milestones=[0, 3, 5], gamma=0.1)

    print('Start training')

    #training
    t0 = timeit.default_timer()
    training_loop(model, dataset, epoch, gamma, optimizer_actor, optimizer_critic, print_loss, device, scheduler_actor, scheduler_critic)
    ttrain = timeit.default_timer() - t0

    print('Training took:', ttrain, 'seconds')

    # Saving the model
    torch.save(model.state_dict(), outdir + '/GPOmodel')

   
