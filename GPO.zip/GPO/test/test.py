import argparse
from pathlib import Path
import pandas as pd
import networkx as nx
import nxmetis


import torch
import torch.nn as nn
import torch.multiprocessing as mp

from torch_geometric.data import Data, DataLoader, Batch
from torch_geometric.nn import SAGEConv, graclus, avg_pool, global_mean_pool, MixHopConv
from torch_geometric.utils import to_networkx, k_hop_subgraph, degree, subgraph, remove_self_loops, from_networkx

import numpy as np
from numpy import random

import scipy
from scipy.sparse import coo_matrix, rand, identity, csc_matrix, csr_matrix
from scipy.io import mmread
from scipy.sparse.linalg import splu

import os
import time

#ND-GPO
def metis_nested_dissection_GPO(model, graph, nmin, device):

    g_stack = [graph]
    i_stack = [[i for i in range(graph.number_of_nodes())]]
    perm = []
    i = 0
    while g_stack:
        gnx = g_stack.pop()
        idx = i_stack.pop()
        if gnx.number_of_nodes() < nmin:
            components_stack = [gnx]
            components_idx_stack = [idx]
            while components_stack:
                gnx_com = components_stack.pop()
                gnx_idx = components_idx_stack.pop()
                if nx.number_connected_components(gnx_com) == 1:
                    g = from_networkx(gnx_com)
                    p= GPOperm_loop(model,g,device)
                    perm = [gnx_idx[i] for i in p] + perm
                 
                    
                else:
                    component = list(nx.connected_components(gnx_com))
                    for subgraph_nodes in component:
                        sub_graph = gnx_com.subgraph(subgraph_nodes)
                        renum_subgraph=nx.convert_node_labels_to_integers(sub_graph,ordering='sorted')
                        sub_num = list(subgraph_nodes)
                        components_idx_stack.append([gnx_idx[i] for i in sub_num])
                        components_stack.append(renum_subgraph)

        else:
            isep, ia, ib = nxmetis.vertex_separator(gnx)

            sepperm = [idx[i] for i in isep]                        
            
            gg = from_networkx(gnx)

            
            gnx_ia = subgraph(
                ia, gg.edge_index, relabel_nodes=True, num_nodes=gnx.number_of_nodes()
            )[0]
            gnx_ib = subgraph(
                ib, gg.edge_index, relabel_nodes=True, num_nodes=gnx.number_of_nodes()
            )[0]
            gnx_isep = subgraph(
                isep, gg.edge_index, relabel_nodes=True, num_nodes=gnx.number_of_nodes()
            )[0]
            ga = Batch(
                batch=torch.zeros(len(ia), 1),
                x=torch.zeros(len(ia), 3), edge_index=gnx_ia
            )
            gb = Batch(
                batch=torch.zeros(len(ib), 1),
                x=torch.zeros(len(ib), 3), edge_index=gnx_ib
            )
            gsep = Batch(
                batch=torch.zeros(len(isep), 1),
                x=torch.zeros(len(isep), 3), edge_index=gnx_isep
            )
            g_stack.append(to_networkx(ga, to_undirected=True))
            i_stack.append([idx[i] for i in ia])
            g_stack.append(to_networkx(gb, to_undirected=True))            
            i_stack.append([idx[i] for i in ib])
            
            
            gnx_renum = to_networkx(gsep, to_undirected=True)
            components_stack = [gnx_renum]
            components_idx_stack = [sepperm]
            while components_stack:
                gnx_com = components_stack.pop()
                gnx_idx = components_idx_stack.pop()
                if nx.number_connected_components(gnx_com) == 1:
                    g = from_networkx(gnx_com)
                    p = GPOperm_loop(model,g,device)
                    perm = [gnx_idx[i] for i in p] + perm
                else:
                    component = list(nx.connected_components(gnx_com))
                    for subgraph_nodes in component:
                        sub_graph = gnx_com.subgraph(subgraph_nodes)
                        renum_subgraph=nx.convert_node_labels_to_integers(sub_graph,ordering='sorted')
                        sub_num = list(subgraph_nodes)
                        components_idx_stack.append([gnx_idx[i] for i in sub_num])
                        components_stack.append(renum_subgraph)            
        i += 1
    return perm

#GPO
def GPOperm_loop(
        model,
        graph,
        device):

    graph.edge_index, _ = remove_self_loops(graph.edge_index)
    Feature = []
    # Get node features
    degs = degree(graph.edge_index[0], num_nodes=graph.num_nodes, dtype=torch.uint8)
    for j in range(graph.num_nodes):
        node_degree_minus_one = degs[j].item() - 1    
        neighbors = graph.edge_index[0] == j
        neighbor_indices = graph.edge_index[1][neighbors]
        neighbor_degrees_sum = degs[neighbor_indices].sum().item() - len(neighbor_indices)
        # Calculate synergy    
        synergy = node_degree_minus_one * neighbor_degrees_sum
        Feature.append([synergy, degs[j],j])
        
    graph.x = torch.tensor(np.array(Feature), dtype=torch.float).to(device)
    start = Batch(batch=torch.zeros(graph.num_nodes, dtype=torch.long, device=device), x=graph.x, edge_index=(graph.edge_index).to(device))
    
    len_episode = graph.num_nodes
    

    timeep = 0
    order = []
    # Here starts the episod related to the graph "start"
    while timeep < len_episode:
        # Model prediction
        policy = model(start)
        probs = policy.view(-1)
        action = torch.argmax(probs).detach().item()

        # Graph update after elimination
        new_state, nnz = remove_vertex(start, action, device)


        order.append(int(start.x[action][2]))
        start = new_state

        timeep += 1
    return order

#vertex elimination process
def remove_vertex(state, vertex, device):
    nnzadd = 0
    
    # Get the degree information of the original state
    original_degrees = state.x[:, 1].clone()

    # Get the neighbors of the vertex    
    neighbors = state.edge_index[1, state.edge_index[0] == vertex]

    # Remove edges associated with the vertex
    mask = (state.edge_index[0] != vertex) & (state.edge_index[1] != vertex)
    new_edge_index = state.edge_index[:, mask]   
    edge_set = set(map(tuple, new_edge_index.t().tolist()))

    # Add edges between non-adjacent neighbors  
    non_neighbors = torch.combinations(neighbors, 2)
    for nn in non_neighbors:
        if (nn[0].item(), nn[1].item()) not in edge_set and (nn[1].item(), nn[0].item()) not in edge_set:
            new_edge = torch.stack([nn, nn.flip(0)], dim=1)
            new_edge_index = torch.cat([new_edge_index, new_edge], dim=1)
            original_degrees[nn] += 1
            nnzadd += 1
            edge_set.update({(nn[0].item(), nn[1].item()), (nn[1].item(), nn[0].item())})

    original_degrees[neighbors] -= 1

    # Update the features of nodes in the affected area
    all_neighbors = set(neighbors.tolist())
    for neighbor in neighbors:
        neighbors_of_neighbor = state.edge_index[1, state.edge_index[0] == neighbor]
        all_neighbors.update(neighbors_of_neighbor.tolist())

    for i in all_neighbors:
        ineighbors = state.edge_index[0] == i
        neighbor_indices = state.edge_index[1][ineighbors]
        neighbor_degrees_sum = original_degrees[neighbor_indices].sum().item() - len(neighbor_indices)
        synergy = (original_degrees[i].item() - 1) * neighbor_degrees_sum
        state.x[i, 0] = synergy

    # Remove the vertex node's attributes and degree information
    new_x = torch.cat([state.x[:vertex], state.x[vertex + 1:]], dim=0)
    new_degrees = torch.cat([original_degrees[:vertex], original_degrees[vertex + 1:]], dim=0)
    
    # Update node indices to account for the removed vertex
    new_edge_index -= (new_edge_index > vertex).type_as(new_edge_index)

    # Create a new x matrix to store each node's label and degree
    new_x = torch.stack([new_x[:, 0], new_degrees, new_x[:, 2]], dim=1).float()

    # Return the new graph
    new_state = Batch(batch=torch.zeros(new_x.shape[0], dtype=torch.long, device=device), x=new_x, edge_index=new_edge_index)

    return new_state, -nnzadd


#Model DRL_GE same as DRL_ND
class ModelDRLGE(torch.nn.Module):
    def __init__(self, units):
        super(ModelSage, self).__init__()

        self.units = units
        self.common_layers = 2
        self.critic_layers = 1
        self.actor_layers = 1
        self.activation = torch.tanh

        self.conv_first = SAGEConv(2, self.units)
        self.conv_common = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.common_layers)]
        )
        self.conv_actor = nn.ModuleList(
            [SAGEConv(self.units,
                      1 if i == self.actor_layers - 1 else self.units)
             for i in range(self.actor_layers)]
        )
        self.conv_critic = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.critic_layers)]
        )
        self.final_critic = nn.Linear(self.units, 1)

    def forward(self, graph):
        x = torch.cat((graph.x[:, 0:1] / (graph.num_nodes*graph.num_nodes), graph.x[:, 1:2] / graph.num_nodes), dim=1)
        edge_index, batch = graph.edge_index, graph.batch

        x = self.activation(self.conv_first(x, edge_index))
        for i in range(self.common_layers):
            x = self.activation(self.conv_common[i](x, edge_index))

        x_actor = x
        for i in range(self.actor_layers):
            x_actor = self.conv_actor[i](x_actor, edge_index)
            if i < self.actor_layers - 1:
                x_actor = self.activation(x_actor)

        x_actor = torch.log_softmax(x_actor, dim=0)
        

        if not self.training:
            return x_actor

        x_critic = x.detach()
        for i in range(self.critic_layers):
            x_critic = self.conv_critic[i](x_critic, edge_index)
            if i < self.critic_layers - 1:
                x_critic = self.activation(x_critic)
        x_critic = self.final_critic(x_critic)
        x_critic = torch.tanh(global_mean_pool(x_critic, batch))
        return x_actor, x_critic

#Model with MixHopConv
class ModelMixHop(torch.nn.Module):
    def __init__(self, input, hidden, output, powers):
        super(ModelMixHop, self).__init__()

        self.input = input
        self.hidden = hidden
        self.output = output
        self.critic_layers = 2
        self.actor_layers = 2
        self.activation = torch.tanh
        self.powers = powers

        self.conv_first_actor = MixHopConv(self.input, self.hidden, self.powers)
        self.conv_first_critic = MixHopConv(self.input, self.hidden, self.powers)

        self.conv_actor = nn.ModuleList(
            [MixHopConv(len(powers)*self.hidden, self.hidden, self.powers)
             for i in range(self.actor_layers)]
        )
        self.conv_critic = nn.ModuleList(
            [MixHopConv(len(powers)*self.hidden, self.hidden, self.powers)
             for i in range(self.critic_layers)]
        )
        self.final_critic = nn.Linear(len(powers)*self.hidden, 1)
        self.final_actor = nn.Linear(len(powers)*self.hidden, 1)

    def forward(self, graph):
        #Normalize node features
        x = torch.cat((graph.x[:, 0:1] / (graph.num_nodes*graph.num_nodes), graph.x[:, 1:2] / graph.num_nodes), dim=1)
        edge_index, batch = graph.edge_index, graph.batch

        x_actor = self.activation(self.conv_first_actor(x, edge_index))

        for i in range(self.actor_layers):
            x_actor = self.conv_actor[i](x_actor, edge_index)
            if i < self.actor_layers - 1:
                x_actor = self.activation(x_actor)
        x_actor = self.final_actor(x_actor)  
        x_actor = torch.log_softmax(x_actor, dim=0)
        

        if not self.training:
            return x_actor

        x_critic = self.activation(self.conv_first_critic(x, edge_index))
        for i in range(self.critic_layers):
            x_critic = self.conv_critic[i](x_critic, edge_index)
            if i < self.critic_layers - 1:
                x_critic = self.activation(x_critic)
        x_critic = self.final_critic(x_critic)
        x_critic = torch.tanh(global_mean_pool(x_critic, batch))
        return x_actor, x_critic

#Model with SAGEConv
class ModelSage(torch.nn.Module):
    def __init__(self, input, units):
        super(ModelSage, self).__init__()

        self.input = input
        self.units = units
        self.critic_layers = 2
        self.actor_layers = 2
        self.activation = torch.tanh

        self.conv_first_actor = SAGEConv(self.input, self.units)
        self.conv_first_critic = SAGEConv(self.input, self.units)

        self.conv_actor = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.actor_layers)]
        )
        self.conv_critic = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.critic_layers)]
        )
        self.final_critic = nn.Linear(self.units, 1)
        self.final_actor = nn.Linear(self.units, 1)

    def forward(self, graph):
        #Normalize node features
        x = torch.cat((graph.x[:, 0:1] / (graph.num_nodes*graph.num_nodes), graph.x[:, 1:2] / graph.num_nodes), dim=1)
        edge_index, batch = graph.edge_index, graph.batch

        x_actor = self.activation(self.conv_first_actor(x, edge_index))

        for i in range(self.actor_layers):
            x_actor = self.conv_actor[i](x_actor, edge_index)
            if i < self.actor_layers - 1:
                x_actor = self.activation(x_actor)
        x_actor = self.final_actor(x_actor)  
        x_actor = torch.log_softmax(x_actor, dim=0)
        

        if not self.training:
            return x_actor

        x_critic = self.activation(self.conv_first_critic(x, edge_index))
        for i in range(self.critic_layers):
            x_critic = self.conv_critic[i](x_critic, edge_index)
            if i < self.critic_layers - 1:
                x_critic = self.activation(x_critic)
        x_critic = self.final_critic(x_critic)
        x_critic = torch.tanh(global_mean_pool(x_critic, batch))
        return x_actor, x_critic

#test function
def matrixtest(model,datedir,files,n_test,device):

    list_picked = []
    GRAPH_NAME = []
    N_GRAPH = []
    NNZ_GRAPH = []

    NNZRATIO_GPO = []
    NNZ_GPO =[]
    GPO_PermT = []
    GPO_LuT = []

    NNZ_METIS = []
    NNZRATIO_METIS = []
    METIS_PermT = []
    METIS_LuT = []

    NNZ_NATRUAL = []
    NNZRATIO_NATRUAL = []
    NATRUAL_LuT = []

    NNZ_COLAMD = []
    NNZRATIO_COLAMD = []
    COLAMD_LuT = []


    num = 0
    index = 0
    
    while num < n_test:
        if len(list_picked) >= len(
            os.listdir(
                os.path.expanduser(
                    datedir))):
            break

        graph = files[index]
        index += 1
        
        if str(graph) not in list_picked:
            list_picked.append(str(graph))
            matrix_sparse = mmread(
                os.path.expanduser(
                    datedir + '/' +
                    str(graph)))
            if matrix_sparse.shape[0] != matrix_sparse.shape[1]:
                continue
            gnx = nx.from_scipy_sparse_array(matrix_sparse).to_undirected()
            if nx.number_connected_components(gnx) >= 1 and gnx.number_of_nodes(
            ) > n_min and gnx.number_of_nodes() < n_max:
                for u, v, data in gnx.edges(data=True):
                    data.clear()
                num += 1
                print(graph)
                GRAPH_NAME.append(graph)
            else:
                continue
        else:
            continue

        print('Graph:', num, '  Vertices:', gnx.number_of_nodes(), '  Edges:', gnx.number_of_edges)
        
        # Set nmin_nd as the node threshold for graph partitioning; set num_blocks as the number of blocks for calculating off-diagonal nnz.
        if gnx.number_of_nodes()<1001:
            nmin_nd = 1001
            num_blocks = 8
        else:
            nmin_nd = 120
            num_blocks = 32
            

        a = nx.to_scipy_sparse_array(
            gnx, format='csc') + 10 * identity(gnx.number_of_nodes())
        nnz = a.nnz
        N_GRAPH.append(gnx.number_of_nodes())
        NNZ_GRAPH.append(nnz)


        #GPO
        start_time = time.perf_counter()
        p = metis_nested_dissection_GPO(model, gnx, nmin_nd, device)
        end_time = time.perf_counter()
        GPO_PermT.append(end_time-start_time)

        aperm = a[:, p][p, :]
        start_time = time.perf_counter()
        lu = splu(aperm, permc_spec='NATURAL')
        end_time = time.perf_counter()
        GPO_LuT.append(end_time-start_time)

        nnz_nd_GPO = lu.L.count_nonzero() + lu.U.count_nonzero() - gnx.number_of_nodes()
        nnzratio_GPO = (nnz_nd_GPO - nnz)/nnz
        NNZRATIO_GPO.append(nnzratio_GPO)
        NNZ_GPO.append(nnz_nd_GPO)
        print('nnz_nd_GPO:',nnz_nd_GPO)



        #metis
        start_time = time.perf_counter()
        p = nxmetis.node_nested_dissection(gnx)
        end_time = time.perf_counter()
        METIS_PermT.append(end_time-start_time)

        aperm = a[:, p][p, :]
        start_time = time.perf_counter()
        lu = splu(aperm, permc_spec='NATURAL')
        end_time = time.perf_counter()
        METIS_LuT.append(end_time-start_time)

        nnz_nd_metis = lu.L.count_nonzero() + lu.U.count_nonzero() - gnx.number_of_nodes()
        nnzratio_metis = (nnz_nd_metis - nnz)/nnz
        NNZ_METIS.append(nnz_nd_metis)
        NNZRATIO_METIS.append(nnzratio_metis)
        print('nnz_nd_metis:',nnz_nd_metis)

        #natrual
        start_time = time.perf_counter()
        lu = splu(a, permc_spec='NATURAL')
        end_time = time.perf_counter()
        NATRUAL_LuT.append(end_time-start_time)

        nnz_nd_natrual = lu.L.count_nonzero() + lu.U.count_nonzero() - gnx.number_of_nodes()
        nnzratio_natrual = (nnz_nd_natrual - nnz)/nnz
        NNZ_NATRUAL.append(nnz_nd_natrual)
        NNZRATIO_NATRUAL.append(nnzratio_natrual)
        print('nnz_nd_natrual:',nnz_nd_natrual)


        #colamd
        start_time = time.perf_counter()
        lu = splu(a, permc_spec='COLAMD')
        end_time = time.perf_counter()
        COLAMD_LuT.append(end_time-start_time)

        nnz_nd_colamd = lu.L.count_nonzero() + lu.U.count_nonzero() - gnx.number_of_nodes()
        nnzratio_colamd = (nnz_nd_colamd - nnz)/nnz
        NNZ_COLAMD.append(nnz_nd_colamd)
        NNZRATIO_COLAMD.append(nnzratio_colamd)
        print('nnz_nd_colamd:',nnz_nd_colamd)


        

    return (GRAPH_NAME, N_GRAPH, NNZ_GRAPH, 
            NNZ_GPO, NNZRATIO_GPO, GPO_PermT, GPO_LuT,  
            NNZ_METIS, NNZRATIO_METIS, METIS_PermT, METIS_LuT, 
            NNZ_NATRUAL, NNZRATIO_NATRUAL, NATRUAL_LuT, 
            NNZ_COLAMD, NNZRATIO_COLAMD, COLAMD_LuT)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument(
        "--nmin",
        default=10,
        help="Minimum graph size",
        type=int)
    parser.add_argument(
        "--nmax",
        default=1000000,
        help="Maximum graph size",
        type=int)
    parser.add_argument(
        "--ntest",
        default=100,
        help="Number of testing graphs",
        type=int)
    parser.add_argument(
        "--units",
        default=16,
        help="Number of units in conv layers",
        type=int)
    parser.add_argument(
        "--modelname",
        default='../modelout/GPOmodel',
        type=str)
    parser.add_argument(
        "--datadir",
        default='../testdata',
        type=str)
    parser.add_argument(
        "--excelpath",
        default='../results/test.xlsx',
        type=str)
    

    torch.manual_seed(1)
    np.random.seed(2)

    args = parser.parse_args()

    n_min = args.nmin
    n_max = args.nmax
    n_test = args.ntest
    units = args.units

    datadir = args.datadir
    datadir = '/home/lzw/RLGEF/data/testdata'
    files = sorted(os.listdir(os.path.expanduser(datadir)))


    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


    # model = ModelSage(units)
    # model = ModelDRLGE(units)
    model = ModelMixHop(2,units,units,[0,1,2])

    model.to(device)
    print(model)

    

    mean = 100
    randommean = 100
    demean = 100    

    
    modelname = args.modelname
    model.load_state_dict(torch.load(modelname, map_location=device))
    model.eval()

    (GRAPH_NAME, N_GRAPH, NNZ_GRAPH, 
            NNZ_GPO, NNZRATIO_GPO, GPO_PermT, GPO_LuT,  
            NNZ_METIS, NNZRATIO_METIS, METIS_PermT, METIS_LuT,
            NNZ_NATRUAL, NNZRATIO_NATRUAL, NATRUAL_LuT, 
            NNZ_COLAMD, NNZRATIO_COLAMD, COLAMD_LuT) = matrixtest(model,datadir,files,n_test,device)
 
    df = pd.DataFrame({
            'GRAPH_NAME': GRAPH_NAME,
            'N_GRAPH': N_GRAPH,
            'NNZ_GRAPH': NNZ_GRAPH,

            'NNZ_NATRUAL' :NNZ_NATRUAL,
            'NNZ_COLAMD' :NNZ_COLAMD,
            'NNZ_METIS' :NNZ_METIS,
            'NNZ_GPO': NNZ_GPO,

            'NNZRATIO_NATRUAL' :NNZRATIO_NATRUAL,
            'NNZRATIO_COLAMD' : NNZRATIO_COLAMD,
            'NNZRATIO_METIS' :NNZRATIO_METIS,
            'NNZRATIO_GPO' : NNZRATIO_GPO,


            'GPO_PermT': GPO_PermT,
            'METIS_PermT': METIS_PermT,

            'NATRUAL_LuT': NATRUAL_LuT,
            'COLAMD_LuT': COLAMD_LuT,            
            'METIS_LuT': METIS_LuT,
            'GPO_LuT': GPO_LuT})
    
    excel_path = args.excelpath
    df.to_excel(excel_path, index=False)