# Learning Fill-in Reduction Ordering via Graph Policy Optimization for Sparse Matrices 
This repository contains the code implementation for the paper Learning Fill-in Reduction Ordering via Graph Policy Optimization for Sparse Matrices. The paper introduces the GPO framework to reorder sparse matrices, aiming to reduce fill-in during matrix decomposition, thereby lowering memory consumption and computation time. This repository provides the training code for GPO as well as testing codes for comparing it with other reordering methods.

## Training the GPO Model
GPO_train.py provides the training process for the GPO, GPO-SAGE, and DRL_GE models, including the generation of the Delaunay dataset used as the training set.

## Training the PPO Model
PPO_train.py provides the training process for the PPO model, including the generation of the Delaunay dataset used as the training set.

## Testing the GPO Model and Comparing with Other Reordering Methods
test.py includes testing code for reordering matrices using NATRUAL, COLAMD, METIS, GPO, PPO, GPO-SAGE, and DRL_GE methods. It evaluates the reordered matrices based on fill-in and LU factorization time.

drl_nd_test.py provides testing code for matrix reordering using DRL_ND, and also includes evaluations of and LU factorization time. This code is based on the implementation from the paper Graph Partitioning and Sparse Matrix Ordering using Reinforcement Learning and Graph Neural Networks. Original code repository: https://github.com/alga-hopf/drl-graph-partitioning.
