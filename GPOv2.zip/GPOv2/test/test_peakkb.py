import argparse
from pathlib import Path
import pandas as pd
import networkx as nx
import nxmetis


import torch
import torch.nn as nn
import torch.multiprocessing as mp

from torch_geometric.data import Data, DataLoader, Batch
from torch_geometric.nn import SAGEConv, graclus, avg_pool, global_mean_pool
from torch_geometric.utils import to_networkx, k_hop_subgraph, degree, subgraph, remove_self_loops, from_networkx
from torch_geometric.utils import coalesce

import numpy as np
from numpy import random

import scipy
from scipy.sparse import coo_matrix, rand, identity, csc_matrix, csr_matrix
from scipy.io import mmread
from scipy.sparse.linalg import splu

import os
import time

import re, json, gc, subprocess, tempfile
from scipy.sparse import save_npz
TIME_BIN = "/usr/bin/time"

import ctypes
libamd = ctypes.cdll.LoadLibrary('../amd/build/libAMDWrapper.so')
# Full evaluation of the DRL-ND model
def ac_eval_coarse_full(ac, graph, k):
    g = graph.clone()
    info = []
    edge_info = []
    while g.num_nodes > 1000:
        edge_info.append(g.edge_index)
        cluster = graclus(g.edge_index, num_nodes=g.num_nodes)
        # print("done cluster")
        info.append(cluster)
        g1 = avg_pool(
            cluster,
            Batch(
                batch=g.batch,
                x=g.x,
                edge_index=g.edge_index))
        g = g1
        # print("nodes",g.num_nodes)

    gnx = to_networkx(g, to_undirected=True)
    # print("begin to partition")
    g = partition_metis(g, gnx)
    # print("done partition")

    while len(info) > 0:
        # print("len(info)",len(info))
        cluster = info.pop()
        _, inverse = torch.unique(cluster, sorted=True, return_inverse=True)
        g.x = g.x[inverse]
        g.edge_index = edge_info.pop()
        gnx = to_networkx(g, to_undirected=True)
        va, vb = volumes(g)
        # print("original va vb",va,vb)
        # print("begin refine")
        g = ac_eval_refine(ac, g, k, gnx, va, vb)
        # print("done refine")
    return g


# Refining the cut on the subgraph around the separator
def ac_eval_refine(ac, graph_test, k, gnx, va, vb, perc=0.05):
    graph = graph_test.clone()
    g0 = graph_test.clone()
    n = separator(graph)
    # print("separator",n)
    # print("begin k_hop_graph_cut")
    data = k_hop_graph_cut(graph, k)
    # print("done k_hop_graph_cut")
    graph_cut, positions = data[0], data[1]
    gnx_sub = to_networkx(graph_cut, to_undirected=True)
    i = 0

    peak_reward = 0
    peak_time = 0
    total_reward = 0
    actions = []

    e = torch.ones(graph_cut.num_nodes, 1)
    nnz = graph.num_nodes
    sep = int(n)
    nodes_separator = torch.where((graph_cut.x[:, 2] == torch.tensor(1.)))[0]
    # print("begin for")
    for i in range(int(n)):
        with torch.no_grad():
            policy = ac(graph_cut)

        probs = policy.view(-1).clone().detach().numpy()
        # print("probs",probs)

        flip = np.argmax(probs)

        # print("va vb",va,vb)

        actions.append(flip)
        if va==0 or vb==0:
            old_sep = 10
        else:
            old_sep = sep * (1 / va + 1 / vb)
        # print("done old_sep")

        graph_cut, a, b, s = change_vertex(graph_cut, flip, gnx_sub, va, vb)
        # print("done change_vertex 1")
        graph, _, _, _ = change_vertex(
            graph, positions[flip].item(), gnx, va, vb)
        # print("done change_vertex 2")

        if a == 1:
            va += 1
            sep -= 1
        elif a == -1:
            va -= 1
            sep += 1
        elif b == 1:
            vb += 1
            sep -= 1
        elif b == -1:
            vb -= 1
            sep += 1
        if va==0 or vb==0:
            new_sep = 10
        else:
            new_sep = sep * (1 / va + 1 / vb)
        total_reward += old_sep - new_sep

        graph_cut.x[:, 5] = torch.true_divide(va, nnz)
        graph_cut.x[:, 6] = torch.true_divide(vb, nnz)

        nodes_separator = torch.where(
            (graph_cut.x[:, 2] == torch.tensor(1.)))[0]
        graph_cut = remove_update(graph_cut, gnx_sub, nodes_separator)
        # print("done remove update")

        if i > 1 and actions[-1] == actions[-2]:
            break
        if total_reward > peak_reward:
            peak_reward = total_reward
            peak_time = i + 1

    for t in range(peak_time):
        g0, _, _, _ = change_vertex(
            g0, positions[actions[t]].item(), gnx, va, vb)

    return g0

# Update the nodes that are necessary to get a minimal separator
def remove_update(gr, gnx, sep):
    graph = gr.clone()
    for ii in sep:
        i = ii.item()
        flagA, flagB = 0, 0
        for v in gnx[i]:
            if flagA == 1 and flagB == 1:
                break
            if graph.x[v, 0] == torch.tensor(1.):
                flagA = 1
            elif graph.x[v, 1] == torch.tensor(1.):
                flagB = 1
        if flagA == 1 and flagB == 1:
            graph.x[i, 4] = torch.tensor(1.)
        else:
            graph.x[i, 4] = torch.tensor(0.)
    return graph


# Full valuation of the DRL model repeated for trials number of times.
# Then the best separator is returned
def ac_eval_coarse_full_trials(ac, graph, k, trials):
    graph_test = graph.clone()
    gg = ac_eval_coarse_full(ac, graph_test, k)
    ncut = normalized_separator(gg)
    for j in range(1, trials):
        # print("j",j)
        gg1 = ac_eval_coarse_full(ac, graph_test, k)
        if normalized_separator(gg1) < ncut:
            ncut = normalized_separator(gg1)
            gg = gg1

    return gg

# Change the feature of the selected vertex v
def change_vertex(g, v, gnx, va, vb):
    a, b, s = 0, 0, 0
    if g.x[v, 2] == 0.:
        if g.x[v, 0] == 1.:
            a, s = -1, 1
        else:
            b, s = -1, 1
        # node v is in A or B, add it to the separator
        g.x[v, :3] = torch.tensor([0., 0., 1.])

        return g, a, b, s
    # node v is in the separator

    for vj in gnx[v]:
        if g.x[vj, 0] == 1.:
            # node v is in the separator and connected to A, so add it
            # to A
            g.x[v, :3] = torch.tensor([1., 0., 0.])
            a, s = 1, -1
            return g, a, b, s
        if g.x[vj, 1] == 1.:
            # node v is in the separator and connected to B, so add it
            # to B
            g.x[v, :3] = torch.tensor([0., 1., 0.])
            b, s = 1, -1
            return g, a, b, s
    # node v is in the separator, but is not connected to A or B.  Add
    # node v to A if the volume of A is less (or equal) to that of B,
    # or to B if the volume of B is less than that of A.
    if va <= vb:
        g.x[v, :3] = torch.tensor([1., 0., 0.])
        s, a = -1, 1
    else:
        g.x[v, :3] = torch.tensor([0., 1., 0.])
        s, b = -1, 1
    return g, a, b, s

# Build a pytorch geometric graph with features [1,0,0] form a networkx graph
def torch_from_graph(graph):
    adj_sparse = nx.to_scipy_sparse_matrix(graph, format='coo')
    row = adj_sparse.row
    col = adj_sparse.col

    one_hot = []
    for i in range(graph.number_of_nodes()):
        one_hot.append([1., 0., 0.])

    edges = torch.tensor([row, col], dtype=torch.long)
    nodes = torch.tensor(np.array(one_hot), dtype=torch.float)
    graph_torch = Data(x=nodes, edge_index=edges)

    return graph_torch

# Build a pytorch geometric graph with features [1,0,0] form a sparse matrix
def torch_from_sparse(adj_sparse):

    row = adj_sparse.row
    col = adj_sparse.col

    features = []
    for i in range(adj_sparse.shape[0]):
        features.append([1., 0., 0.])

    edges = torch.tensor([row, col], dtype=torch.long)
    nodes = torch.tensor(np.array(features), dtype=torch.float)
    graph_torch = Data(x=nodes, edge_index=edges)

    return graph_torch


# Number of vertices in the separator
def separator(graph):
    sep = torch.where((graph.x == torch.tensor(
        [0., 0., 1.])).all(axis=-1))[0].shape[0]
    return sep

# Normalized separator
def normalized_separator(graph):
    da, db = volumes(graph)
    sep = torch.where((graph.x == torch.tensor(
        [0., 0., 1.])).all(axis=-1))[0].shape[0]
    if da == 0 or db == 0:
        return 10
    else:
        return sep * (1 / da + 1 / db)

# Normalized separator for METIS
def vertex_sep_metis(graph, gnx):
    sep, nodes1, nodes2 = nxmetis.vertex_separator(gnx)
    da = len(nodes1)
    db = len(nodes2)
    return len(sep) * (1 / da + 1 / db)

# Subgraph around the separator
def k_hop_graph_cut(graph, k):
    nei = torch.where((graph.x[:, 2] == torch.tensor(1.)))[0]
    data_cut = k_hop_subgraph(
        nei,
        k,
        graph.edge_index,
        relabel_nodes=True,
        num_nodes=graph.num_nodes)
    data_small = k_hop_subgraph(
        nei,
        k - 1,
        graph.edge_index,
        relabel_nodes=True,
        num_nodes=graph.num_nodes)
    nodes_boundary = list(
        set(data_cut[0].numpy()).difference(data_small[0].numpy()))
    boundary_features = torch.tensor([1. if i.item(
    ) in nodes_boundary else 0. for i in data_cut[0]]).reshape(data_cut[0].shape[0], 1)
    remove_f = []
    for j in range(len(data_cut[0])):
        if graph.x[data_cut[0][j]][2] == torch.tensor(1.):
            neighbors, _, _, _ = k_hop_subgraph(
                [data_cut[0][j]], 1, graph.edge_index, relabel_nodes=True, num_nodes=graph.num_nodes)
            flagA, flagB = 0, 0
            for w in neighbors:
                if graph.x[w][0] == torch.tensor(1.):
                    flagA = 1
                elif graph.x[w][1] == torch.tensor(1.):
                    flagB = 1
            if flagA == 1 and flagB == 1:
                remove_f.append(1.)
            else:
                remove_f.append(0.)
        else:
            remove_f.append(0.)
    remove_features = torch.tensor(remove_f).reshape(len(remove_f), 1)
    va, vb = volumes(graph)
    e = torch.ones(data_cut[0].shape[0], 1)
    nnz = graph.num_nodes
    features = torch.cat((graph.x[data_cut[0]],
                          boundary_features,
                          remove_features,
                          torch.true_divide(va,
                                            nnz) * e,
                          torch.true_divide(vb,
                                            nnz) * e),
                         1)
    g_red = Batch(
        batch=torch.zeros(
            data_cut[0].shape[0],
            dtype=torch.long),
        x=features,
        edge_index=data_cut[1])
    return g_red, data_cut[0]

# Cardinalities of the partitions A and B
def volumes(graph):
    ab = torch.sum(graph.x, dim=0)
    return ab[0].item(), ab[1].item()

# Coarsen a pytorch geometric graph, then find the separator with METIS
# and interpolate it back
def partition_metis_refine(graph):
    cluster = graclus(graph.edge_index, num_nodes=graph.num_nodes)
    coarse_graph = avg_pool(
        cluster,
        Batch(
            batch=graph.batch,
            x=graph.x,
            edge_index=graph.edge_index))
    coarse_graph_nx = to_networkx(coarse_graph, to_undirected=True)
    sep, A, B = nxmetis.vertex_separator(coarse_graph_nx)
    coarse_graph.x[sep] = torch.tensor([0., 0., 1.])
    coarse_graph.x[A] = torch.tensor([1., 0., 0.])
    coarse_graph.x[B] = torch.tensor([0., 1., 0.])
    _, inverse = torch.unique(cluster, sorted=True, return_inverse=True)
    graph.x = coarse_graph.x[inverse]
    return graph

# Separator of a pytorch geometric graph obtained with METIS
def partition_metis(coarse_graph, coarse_graph_nx):
    options = nxmetis.MetisOptions(ubvec=[1.01], minconn=True, contig=True)
    sep, A, B = nxmetis.vertex_separator(coarse_graph_nx,options=options)
    coarse_graph.x[sep] = torch.tensor([0., 0., 1.])
    coarse_graph.x[A] = torch.tensor([1., 0., 0.])
    coarse_graph.x[B] = torch.tensor([0., 1., 0.])
    # print(coarse_graph_nx)
    # print("Nodes:", list(coarse_graph_nx.nodes))
    # print("Edges:", list(coarse_graph_nx.edges))
    # print("len",len(sep),len(A),len(B))
    return coarse_graph



def amd_ordering(g):
    gnx = to_networkx(g, to_undirected=True)
    n = g.num_nodes
    a = nx.to_scipy_sparse_matrix(gnx, format="csr", dtype=np.float32)
    a += identity(n)
    perm = np.zeros(n, dtype=np.int32)
    iperm = np.zeros(n, dtype=np.int32)
    libamd.WRAPPER_amd(
        ctypes.c_int(n),
        ctypes.c_void_p(a.indptr.ctypes.data),
        ctypes.c_void_p(a.indices.ctypes.data),
        ctypes.c_void_p(perm.ctypes.data),
        ctypes.c_void_p(iperm.ctypes.data)
    )
    return perm.tolist()


# Nested dissection ordering with the DRL algorithm
def drl_nested_dissection(graph, nmin, hops, model, trials, lvl=0):
    # print("begin to nested dissection")
    g_stack = [graph]
    i_stack = [[i for i in range(graph.num_nodes)]]
    perm = []
    i = 0
    while g_stack:
        g = g_stack.pop()
        idx = i_stack.pop()
        if g.num_nodes < nmin:
            if g.num_nodes > 0:
                p = amd_ordering(g)
                perm = [idx[i] for i in p] + perm
                # print("amd")
        else:
            g = ac_eval_coarse_full_trials(model, g, hops, trials)
            ia = torch.where(g.x[:, 0] == 1.)[0].tolist()
            ib = torch.where(g.x[:, 1] == 1.)[0].tolist()
            isep = torch.where(g.x[:, 2] == 1.)[0].tolist()
            ga_data = subgraph(
                ia, g.edge_index, relabel_nodes=True, num_nodes=g.num_nodes
            )[0]
            gb_data = subgraph(
                ib, g.edge_index, relabel_nodes=True, num_nodes=g.num_nodes
            )[0]
            ga = Batch(
                batch=torch.zeros(len(ia), 1),
                x=torch.zeros(len(ia), 3), edge_index=ga_data
            )
            gb = Batch(
                batch=torch.zeros(len(ib), 1),
                x=torch.zeros(len(ib), 3), edge_index=gb_data
            )
            g_stack.append(ga)
            i_stack.append([idx[i] for i in ia])
            g_stack.append(gb)
            i_stack.append([idx[i] for i in ib])
            perm = [idx[i] for i in isep] + perm
        i += 1
        # print("i",i)
    return perm



#DRL_ND 
class Model(torch.nn.Module):
    def __init__(self, units):
        super(Model, self).__init__()

        self.units = units
        self.common_layers = 1
        self.critic_layers = 1
        self.actor_layers = 1
        self.activation = torch.tanh

        self.conv_first = SAGEConv(7, self.units)
        self.conv_common = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.common_layers)]
        )
        self.conv_actor = nn.ModuleList(
            [SAGEConv(self.units,
                      1 if i == self.actor_layers - 1 else self.units)
             for i in range(self.actor_layers)]
        )
        self.conv_critic = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.critic_layers)]
        )
        self.final_critic = nn.Linear(self.units, 1)

    def forward(self, graph):
        x, edge_index, batch = graph.x, graph.edge_index, graph.batch

        do_not_flip = torch.where(x[:, 3] != 0.)
        do_not_flip_2 = torch.where(x[:, 4] != 0.)

        x = self.activation(self.conv_first(x, edge_index))
        for i in range(self.common_layers):
            x = self.activation(self.conv_common[i](x, edge_index))

        x_actor = x
        for i in range(self.actor_layers):
            x_actor = self.conv_actor[i](x_actor, edge_index)
            if i < self.actor_layers - 1:
                x_actor = self.activation(x_actor)
        x_actor[do_not_flip] = torch.tensor(-np.Inf)
        x_actor[do_not_flip_2] = torch.tensor(-np.Inf)
        x_actor = torch.log_softmax(x_actor, dim=0)

        if not self.training:
            return x_actor

        x_critic = x.detach()
        for i in range(self.critic_layers):
            x_critic = self.conv_critic[i](x_critic, edge_index)
            if i < self.critic_layers - 1:
                x_critic = self.activation(x_critic)
        x_critic = self.final_critic(x_critic)
        x_critic = torch.tanh(global_mean_pool(x_critic, batch))
        return x_actor, x_critic

def _parse_time_v(stderr_text):
    peak_kb = None
    elapsed_sec = None
    m = re.search(r"Maximum resident set size \(kbytes\):\s*(\d+)", stderr_text, re.I)
    if m: peak_kb = int(m.group(1))
    m = re.search(r"Elapsed \(wall clock\) time.*:\s*([0-9:\.]+)", stderr_text)
    if m:
        s = m.group(1).strip()
        parts = s.split(":")
        try:
            if len(parts) == 3:
                h, mm, ss = int(parts[0]), int(parts[1]), float(parts[2])
                elapsed_sec = h*3600 + mm*60 + ss
            elif len(parts) == 2:
                mm, ss = int(parts[0]), float(parts[1])
                elapsed_sec = mm*60 + ss
            else:
                elapsed_sec = float(parts[0])
        except Exception:
            pass
    return peak_kb, elapsed_sec

def _run_lu_npz_subprocess(npz_path, method, diag_pivot_thresh=1.0):

    cmd = [TIME_BIN, "-v", "python", "-u", "run_lu_once.py",
           "--npz", npz_path, "--method", method, "--diag_pivot_thresh", str(diag_pivot_thresh)]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, text=True)
    json_out = json.loads(proc.stdout.strip())
    peak_kb, elapsed_sec = _parse_time_v(proc.stderr)
    return json_out, peak_kb, elapsed_sec

def _run_lu_subprocess(mtx_path, method, perm=None, diag_pivot_thresh=1.0):

    cmd = [TIME_BIN, "-v", "python", "-u", "run_lu_once.py",
           "--mtx", mtx_path, "--method", method,
           "--diag_pivot_thresh", str(diag_pivot_thresh)]
    tmp_perm = None
    if method == "EXTERNAL":
        assert perm is not None
        tmp_perm = tempfile.NamedTemporaryFile(prefix="perm_", suffix=".npy", delete=False)
        np.save(tmp_perm.name, np.asarray(perm, dtype=np.int64)) 
        tmp_perm.flush()
        cmd += ["--perm_npy", tmp_perm.name]

    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          check=True, text=True)
    stdout, stderr = proc.stdout, proc.stderr
    json_out = json.loads(stdout.strip())
    peak_kb, elapsed_sec = _parse_time_v(stderr)

    if tmp_perm is not None:
        try: os.unlink(tmp_perm.name)
        except Exception: pass

    return json_out, peak_kb, elapsed_sec

def _edge_index_to_nx_graph(edge_index: torch.Tensor, num_nodes: int) -> nx.Graph:

    G = nx.Graph()
    G.add_nodes_from(range(num_nodes))
    if edge_index.numel() > 0:
        ei = edge_index.detach().cpu().numpy()
        G.add_edges_from(ei.T.tolist())
    return G


#ND-GPO
def metis_nested_dissection(model, graph, nmin, device):

    g_stack = [graph]
    i_stack = [[i for i in range(graph.number_of_nodes())]]
    perm = []
    i = 0
    while g_stack:
        gnx = g_stack.pop()
        idx = i_stack.pop()
        if gnx.number_of_nodes() < nmin:
            components_stack = [gnx]
            components_idx_stack = [idx]
            while components_stack:
                gnx_com = components_stack.pop()
                gnx_idx = components_idx_stack.pop()
                if nx.number_connected_components(gnx_com) == 1:
                    g = from_networkx(gnx_com)
                    p= GPOperm_loop(model,g,device)
                    perm = [gnx_idx[i] for i in p] + perm
                 
                    
                else:
                    component = list(nx.connected_components(gnx_com))
                    for subgraph_nodes in component:
                        sub_graph = gnx_com.subgraph(subgraph_nodes)
                        renum_subgraph=nx.convert_node_labels_to_integers(sub_graph,ordering='sorted')
                        sub_num = list(subgraph_nodes)
                        components_idx_stack.append([gnx_idx[i] for i in sub_num])
                        components_stack.append(renum_subgraph)

        else:
            isep, ia, ib = nxmetis.vertex_separator(gnx)

            sepperm = [idx[i] for i in isep]                        
            
            gg = from_networkx(gnx)

            
            gnx_ia = subgraph(
                ia, gg.edge_index, relabel_nodes=True, num_nodes=gnx.number_of_nodes()
            )[0]
            gnx_ib = subgraph(
                ib, gg.edge_index, relabel_nodes=True, num_nodes=gnx.number_of_nodes()
            )[0]
            gnx_isep = subgraph(
                isep, gg.edge_index, relabel_nodes=True, num_nodes=gnx.number_of_nodes()
            )[0]
            ga = Batch(
                batch=torch.zeros(len(ia), 1),
                x=torch.zeros(len(ia), 3), edge_index=gnx_ia
            )
            gb = Batch(
                batch=torch.zeros(len(ib), 1),
                x=torch.zeros(len(ib), 3), edge_index=gnx_ib
            )
            gsep = Batch(
                batch=torch.zeros(len(isep), 1),
                x=torch.zeros(len(isep), 3), edge_index=gnx_isep
            )
            g_stack.append(to_networkx(ga, to_undirected=True))
            i_stack.append([idx[i] for i in ia])
            g_stack.append(to_networkx(gb, to_undirected=True))            
            i_stack.append([idx[i] for i in ib])
            
            
            
            gnx_renum = to_networkx(gsep, to_undirected=True)
            components_stack = [gnx_renum]
            components_idx_stack = [sepperm]
            while components_stack:
                gnx_com = components_stack.pop()
                gnx_idx = components_idx_stack.pop()
                if nx.number_connected_components(gnx_com) == 1:
                    g = from_networkx(gnx_com)
                    p = GPOperm_loop(model,g,device)
                    perm = [gnx_idx[i] for i in p] + perm
                    # print(len(p),flush=True)
                    # print("per:",len(perm),flush=True)
                else:
                    component = list(nx.connected_components(gnx_com))
                    for subgraph_nodes in component:
                        sub_graph = gnx_com.subgraph(subgraph_nodes)
                        renum_subgraph=nx.convert_node_labels_to_integers(sub_graph,ordering='sorted')
                        sub_num = list(subgraph_nodes)
                        components_idx_stack.append([gnx_idx[i] for i in sub_num])
                        components_stack.append(renum_subgraph)            
        i += 1
    return perm


def GPOperm_loop(
        model,
        graph,
        device):

    graph.edge_index, _ = remove_self_loops(graph.edge_index)
    Feature = []
    # Get node features
    degs = degree(graph.edge_index[0], num_nodes=graph.num_nodes, dtype=torch.uint8)
    for j in range(graph.num_nodes):
        node_degree_minus_one = degs[j].item() - 1    
        neighbors = graph.edge_index[0] == j
        neighbor_indices = graph.edge_index[1][neighbors]
        neighbor_degrees_sum = degs[neighbor_indices].sum().item() - len(neighbor_indices)
        # Calculate synergy    
        synergy = node_degree_minus_one * neighbor_degrees_sum
        Feature.append([synergy, degs[j],j])
        
    graph.x = torch.tensor(np.array(Feature), dtype=torch.float).to(device)
    start = Batch(batch=torch.zeros(graph.num_nodes, dtype=torch.long, device=device), x=graph.x, edge_index=(graph.edge_index).to(device))
    
    len_episode = graph.num_nodes
    

    timeep = 0
    order = []
    # Here starts the episod related to the graph "start"
    while timeep < len_episode:
        # Model prediction
        policy = model(start)
        probs = policy.view(-1)
        action = torch.argmax(probs).detach().item()

        # Graph update after elimination
        new_state, nnz = remove_vertex(start, action, device)


        order.append(int(start.x[action][2]))
        start = new_state

        timeep += 1
    return order

#vertex elimination process
def remove_vertex(state, vertex, device):
    nnzadd = 0
    
    # Get the degree information of the original state
    original_degrees = state.x[:, 1].clone()

    # Get the neighbors of the vertex    
    neighbors = state.edge_index[1, state.edge_index[0] == vertex]

    # Remove edges associated with the vertex
    mask = (state.edge_index[0] != vertex) & (state.edge_index[1] != vertex)
    new_edge_index = state.edge_index[:, mask]   
    edge_set = set(map(tuple, new_edge_index.t().tolist()))

    # Add edges between non-adjacent neighbors  
    non_neighbors = torch.combinations(neighbors, 2)
    for nn in non_neighbors:
        if (nn[0].item(), nn[1].item()) not in edge_set and (nn[1].item(), nn[0].item()) not in edge_set:
            new_edge = torch.stack([nn, nn.flip(0)], dim=1)
            new_edge_index = torch.cat([new_edge_index, new_edge], dim=1)
            original_degrees[nn] += 1
            nnzadd += 1
            edge_set.update({(nn[0].item(), nn[1].item()), (nn[1].item(), nn[0].item())})

    original_degrees[neighbors] -= 1

    # Update the features of nodes in the affected area
    all_neighbors = set(neighbors.tolist())
    for neighbor in neighbors:
        neighbors_of_neighbor = state.edge_index[1, state.edge_index[0] == neighbor]
        all_neighbors.update(neighbors_of_neighbor.tolist())

    for i in all_neighbors:
        ineighbors = state.edge_index[0] == i
        neighbor_indices = state.edge_index[1][ineighbors]
        neighbor_degrees_sum = original_degrees[neighbor_indices].sum().item() - len(neighbor_indices)
        synergy = (original_degrees[i].item() - 1) * neighbor_degrees_sum
        state.x[i, 0] = synergy

    # Remove the vertex node's attributes and degree information
    new_x = torch.cat([state.x[:vertex], state.x[vertex + 1:]], dim=0)
    new_degrees = torch.cat([original_degrees[:vertex], original_degrees[vertex + 1:]], dim=0)
    
    # Update node indices to account for the removed vertex
    new_edge_index -= (new_edge_index > vertex).type_as(new_edge_index)

    # Create a new x matrix to store each node's label and degree
    new_x = torch.stack([new_x[:, 0], new_degrees, new_x[:, 2]], dim=1).float()

    # Return the new graph
    new_state = Batch(batch=torch.zeros(new_x.shape[0], dtype=torch.long, device=device), x=new_x, edge_index=new_edge_index)

    return new_state, -nnzadd


#Model with SAGEConv
class ModelSage(torch.nn.Module):
    def __init__(self, input, units):
        super(ModelSage, self).__init__()

        self.input = input
        self.units = units
        self.critic_layers = 2
        self.actor_layers = 2
        self.activation = torch.tanh

        self.conv_first_actor = SAGEConv(self.input, self.units)
        self.conv_first_critic = SAGEConv(self.input, self.units)

        self.conv_actor = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.actor_layers)]
        )
        self.conv_critic = nn.ModuleList(
            [SAGEConv(self.units, self.units)
             for i in range(self.critic_layers)]
        )
        self.final_critic = nn.Linear(self.units, 1)
        self.final_actor = nn.Linear(self.units, 1)

    def forward(self, graph):
        #Normalize node features
        x = torch.cat((graph.x[:, 0:1] / (graph.num_nodes*graph.num_nodes), graph.x[:, 1:2] / graph.num_nodes), dim=1)
        edge_index, batch = graph.edge_index, graph.batch

        x_actor = self.activation(self.conv_first_actor(x, edge_index))

        for i in range(self.actor_layers):
            x_actor = self.conv_actor[i](x_actor, edge_index)
            if i < self.actor_layers - 1:
                x_actor = self.activation(x_actor)
        x_actor = self.final_actor(x_actor)  
        x_actor = torch.log_softmax(x_actor, dim=0)
        

        if not self.training:
            return x_actor

        x_critic = self.activation(self.conv_first_critic(x, edge_index))
        for i in range(self.critic_layers):
            x_critic = self.conv_critic[i](x_critic, edge_index)
            if i < self.critic_layers - 1:
                x_critic = self.activation(x_critic)
        x_critic = self.final_critic(x_critic)
        x_critic = torch.tanh(global_mean_pool(x_critic, batch))
        return x_actor, x_critic

#test function
def matrixtest(gpomodel, ppomodel, drlndmodel, datedir, files, n_test, device):
    import os, time
    import numpy as np
    import networkx as nx, nxmetis
    from scipy.io import mmread
    from scipy.sparse import identity
    from scipy.sparse import save_npz

    list_picked = []
    GRAPH_NAME, N_GRAPH, NNZ_GRAPH = [], [], []

    NNZRATIO_GPO, NNZ_GPO, GPO_PermT, GPO_LuT = [], [], [], []
    NNZ_METIS, NNZRATIO_METIS, METIS_PermT, METIS_LuT = [], [], [], []
    NNZ_NATRUAL, NNZRATIO_NATRUAL, NATRUAL_LuT = [], [], []
    NNZ_COLAMD, NNZRATIO_COLAMD, COLAMD_LuT = [], [], []

    BYTESF_GPO, BYTESF_METIS, BYTESF_NATURAL, BYTESF_COLAMD = [], [], [], []
    PEAKRSS_GPO_LU, PEAKRSS_METIS_LU, PEAKRSS_NATURAL_LU, PEAKRSS_COLAMD_LU = [], [], [], []

    num = 0; index = 0
    while num < n_test:
        if len(list_picked) >= len(os.listdir(os.path.expanduser(datedir))): break

        graph = files[index]; index += 1
        if str(graph) in list_picked: continue
        list_picked.append(str(graph))

        mtx_path = os.path.join(os.path.expanduser(datedir), str(graph))
        matrix_sparse = mmread(mtx_path)
        if matrix_sparse.shape[0] != matrix_sparse.shape[1]: continue

        gnx = nx.from_scipy_sparse_matrix(matrix_sparse).to_undirected()
        if nx.number_connected_components(gnx) >= 1 and gnx.number_of_nodes() > n_min and gnx.number_of_nodes() < n_max:
            for u, v, data in gnx.edges(data=True): data.clear()
            num += 1; print(graph); GRAPH_NAME.append(graph)
        else:
            continue

        print('Graph:', num, '  Vertices:', gnx.number_of_nodes(), '  Edges:', gnx.number_of_edges())

        if gnx.number_of_nodes() < 1001: nmin_nd, num_blocks = 1001, 8
        else:                            nmin_nd, num_blocks = 120, 32

        a = nx.to_scipy_sparse_matrix(gnx, format='csc') + 10 * identity(gnx.number_of_nodes())
        a.sort_indices(); a.sum_duplicates()
        nnz = a.nnz
        N_GRAPH.append(gnx.number_of_nodes()); NNZ_GRAPH.append(nnz)

        # ---------- GPO ----------
        t0 = time.perf_counter()
        p = metis_nested_dissection(gpomodel, gnx, nmin_nd, device)
        t1 = time.perf_counter()
        GPO_PermT.append(t1 - t0); print("GPO_time:", t1 - t0, flush=True)

        p = np.asarray(p, dtype=np.int64)  # list -> ndarray
        aperm = a[:, p][p, :]
        with tempfile.NamedTemporaryFile(prefix="A_gpo_", suffix=".npz", delete=False) as f_gpo:
            save_npz(f_gpo.name, aperm)
            jout, peak_kb, elapsed = _run_lu_npz_subprocess(f_gpo.name, method="NATURAL")
        try: os.unlink(f_gpo.name)
        except Exception: pass

        GPO_LuT.append(elapsed); PEAKRSS_GPO_LU.append(peak_kb)
        NNZ_GPO.append(jout["nnzF_minus_n"])
        NNZRATIO_GPO.append((jout["nnzF_minus_n"] - nnz) / nnz)
        BYTESF_GPO.append(jout["bytesF"])
        print("GPO_LU_time(s):", elapsed, "peak_kB:", peak_kb, "nnzF-n:", jout["nnzF_minus_n"], flush = True)

        # ---------- PPO ----------
        t0 = time.perf_counter()
        p = metis_nested_dissection(ppomodel, gnx, nmin_nd, device)
        t1 = time.perf_counter()
        PPO_PermT.append(t1 - t0); print("PPO_time:", t1 - t0, flush=True)

        p = np.asarray(p, dtype=np.int64)  # list -> ndarray
        aperm = a[:, p][p, :]
        with tempfile.NamedTemporaryFile(prefix="A_ppo_", suffix=".npz", delete=False) as f_ppo:
            save_npz(f_ppo.name, aperm)
            jout, peak_kb, elapsed = _run_lu_npz_subprocess(f_ppo.name, method="NATURAL")
        try: os.unlink(f_ppo.name)
        except Exception: pass

        PPO_LuT.append(elapsed); PEAKRSS_PPO_LU.append(peak_kb)
        NNZ_PPO.append(jout["nnzF_minus_n"])
        NNZRATIO_PPO.append((jout["nnzF_minus_n"] - nnz) / nnz)
        BYTESF_PPO.append(jout["bytesF"])
        print("PPO_LU_time(s):", elapsed, "peak_kB:", peak_kb, "nnzF-n:", jout["nnzF_minus_n"], flush = True)

        # ---------- DRL_ND ----------
        t0 = time.perf_counter()
        g = torch_from_sparse(matrix_sparse)
        g.weight = torch.tensor([1] * g.num_edges)
        g.batch = torch.zeros(g.num_nodes)
        p = drl_nested_dissection(g, nmin_nd, 3, drlndmodel, 0, lvl=0)
        t1 = time.perf_counter()
        DRLND_PermT.append(t1 - t0); print("DRLND_time:", t1 - t0, flush=True)

        p = np.asarray(p, dtype=np.int64)  # list -> ndarray
        aperm = a[:, p][p, :]
        with tempfile.NamedTemporaryFile(prefix="A_drlnd_", suffix=".npz", delete=False) as f_drlnd:
            save_npz(f_drlnd.name, aperm)
            jout, peak_kb, elapsed = _run_lu_npz_subprocess(f_drlnd.name, method="NATURAL")
        try: os.unlink(f_drlnd.name)
        except Exception: pass

        DRLND_LuT.append(elapsed); PEAKRSS_DRLND_LU.append(peak_kb)
        NNZ_DRLND.append(jout["nnzF_minus_n"])
        NNZRATIO_DRLND.append((jout["nnzF_minus_n"] - nnz) / nnz)
        BYTESF_DRLND.append(jout["bytesF"])
        print("DRLND_LU_time(s):", elapsed, "peak_kB:", peak_kb, "nnzF-n:", jout["nnzF_minus_n"], flush = True)

        # ---------- METIS（外部置换：父进程中完成） ----------
        t0 = time.perf_counter()
        p = nxmetis.node_nested_dissection(gnx)
        t1 = time.perf_counter()
        METIS_PermT.append(t1 - t0); print("METIS_time:", t1 - t0)

        p = np.asarray(p, dtype=np.int64)
        aperm = a[:, p][p, :]
        with tempfile.NamedTemporaryFile(prefix="A_metis_", suffix=".npz", delete=False) as f_metis:
            save_npz(f_metis.name, aperm)
            jout, peak_kb, elapsed = _run_lu_npz_subprocess(f_metis.name, method="NATURAL")
        try: os.unlink(f_metis.name)
        except Exception: pass

        METIS_LuT.append(elapsed); PEAKRSS_METIS_LU.append(peak_kb)
        NNZ_METIS.append(jout["nnzF_minus_n"])
        NNZRATIO_METIS.append((jout["nnzF_minus_n"] - nnz) / nnz)
        BYTESF_METIS.append(jout["bytesF"])
        print("METIS_LU_time(s):", elapsed, "peak_kB:", peak_kb, "nnzF-n:", jout["nnzF_minus_n"])

        # ---------- COLAMD（内置：父进程只存原 A） ----------
        with tempfile.NamedTemporaryFile(prefix="A_colamd_", suffix=".npz", delete=False) as f_colamd:
            save_npz(f_colamd.name, a)
            jout, peak_kb, elapsed = _run_lu_npz_subprocess(f_colamd.name, method="COLAMD")
        try: os.unlink(f_colamd.name)
        except Exception: pass

        COLAMD_LuT.append(elapsed); PEAKRSS_COLAMD_LU.append(peak_kb)
        NNZ_COLAMD.append(jout["nnzF_minus_n"])
        NNZRATIO_COLAMD.append((jout["nnzF_minus_n"] - nnz) / nnz)
        BYTESF_COLAMD.append(jout["bytesF"])
        print("COLAMD_time(s):", elapsed, "peak_kB:", peak_kb, "nnzF-n:", jout["nnzF_minus_n"])

        # ---------- NATURAL（无列重排：父进程只存原 A） ----------
        with tempfile.NamedTemporaryFile(prefix="A_nat_", suffix=".npz", delete=False) as f_nat:
            save_npz(f_nat.name, a)
            jout, peak_kb, elapsed = _run_lu_npz_subprocess(f_nat.name, method="NATURAL")
        try: os.unlink(f_nat.name)
        except Exception: pass

        NATRUAL_LuT.append(elapsed); PEAKRSS_NATURAL_LU.append(peak_kb)
        NNZ_NATRUAL.append(jout["nnzF_minus_n"])
        NNZRATIO_NATRUAL.append((jout["nnzF_minus_n"] - nnz) / nnz)
        BYTESF_NATURAL.append(jout["bytesF"])
        print("NATURAL_time(s):", elapsed, "peak_kB:", peak_kb, "nnzF-n:", jout["nnzF_minus_n"])

    return (GRAPH_NAME, N_GRAPH, NNZ_GRAPH,
            NNZ_GPO, NNZRATIO_GPO, GPO_PermT, GPO_LuT,
            NNZ_PPO, NNZRATIO_PPO, PPO_PermT, PPO_LuT,
            NNZ_DRLND, NNZRATIO_DRLND, DRLND_PermT, DRLND_LuT,
            NNZ_METIS, NNZRATIO_METIS, METIS_PermT, METIS_LuT,
            NNZ_NATRUAL, NNZRATIO_NATRUAL, NATRUAL_LuT,
            NNZ_COLAMD, NNZRATIO_COLAMD, COLAMD_LuT,
            BYTESF_GPO, BYTESF_PPO, BYTESF_DRLND, BYTESF_METIS, BYTESF_NATURAL, BYTESF_COLAMD,
            PEAKRSS_GPO_LU, PEAKRSS_PPO_LU, PEAKRSS_DRLND_LU,PEAKRSS_METIS_LU, PEAKRSS_NATURAL_LU, PEAKRSS_COLAMD_LU)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument(
        "--nmin",
        default=10,
        help="Minimum graph size",
        type=int)
    parser.add_argument(
        "--nmax",
        default=1000000,
        help="Maximum graph size",
        type=int)
    parser.add_argument(
        "--ntest",
        default=10,
        help="Number of testing graphs",
        type=int)
    parser.add_argument(
        "--units",
        default=7,
        help="Number of units in conv layers",
        type=int)
    parser.add_argument(
        "--gpomodel",
        default='../modelout/gpomodel',
        type=str)
    parser.add_argument(
        "--ppomodel",
        default='../modelout/ppomodel',
        type=str)
    parser.add_argument(
        "--drlndmodel",
        default='../modelout/drlndmodel',
        type=str)
    parser.add_argument(
        "--datadir",
        default='../testdata',
        type=str)
    parser.add_argument(
        "--excelpath",
        default='../results/test_memory.xlsx',
        type=str)
    

    torch.manual_seed(1)
    np.random.seed(2)

    args = parser.parse_args()

    n_min = args.nmin
    n_max = args.nmax
    n_test = args.ntest
    units = args.units

    datadir = args.datadir

    files = sorted(os.listdir(os.path.expanduser(datadir)))


    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    gpomodel = ModelMixHop(2,units,units,[0,1,2]).to(device)
    ppomodel = ModelMixHop(2,units,units,[0,1,2]).to(device)
    drlndmodel = Model(units)

    print(model)
    
    gpomodel.load_state_dict(torch.load(args.gpomodel, map_location=device))
    ppomodel.load_state_dict(torch.load(args.ppomodel, map_location=device))
    drlndmodel.load_state_dict(torch.load(args.drlndmodel, map_location=device))
    gpomodel.eval()
    ppomodel.eval()
    drlndmodel.eval()


    (GRAPH_NAME, N_GRAPH, NNZ_GRAPH, 
            NNZ_GPO, NNZRATIO_GPO, GPO_PermT, GPO_LuT,
            NNZ_PPO, NNZRATIO_PPO, PPO_PermT, PPO_LuT,
            NNZ_DRLND, NNZRATIO_DRLND, DRLND_PermT, DRLND_LuT,
            NNZ_METIS, NNZRATIO_METIS, METIS_PermT, METIS_LuT,
            NNZ_NATRUAL, NNZRATIO_NATRUAL, NATRUAL_LuT, 
            NNZ_COLAMD, NNZRATIO_COLAMD, COLAMD_LuT,
            BYTESF_GPO, BYTESF_PPO, BYTESF_DRLND, BYTESF_METIS, BYTESF_NATURAL, BYTESF_COLAMD,
            PEAKRSS_GPO_LU, PEAKRSS_PPO_LU, PEAKRSS_DRLND_LU,PEAKRSS_METIS_LU, PEAKRSS_NATURAL_LU, PEAKRSS_COLAMD_LU
    ) = matrixtest(gpomodel, ppomodel, drlndmodel, datadir,files,n_test,device)