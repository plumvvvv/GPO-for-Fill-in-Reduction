import argparse, json
from scipy.sparse import load_npz
from scipy.sparse.linalg import splu

def _bytes_of_sparse(M):
    return M.data.nbytes + M.indices.nbytes + M.indptr.nbytes

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--npz", required=True)
    ap.add_argument("--method", required=True, choices=["NATURAL", "COLAMD"])
    ap.add_argument("--diag_pivot_thresh", type=float, default=1.0)
    args = ap.parse_args()

    A = load_npz(args.npz).tocsc()
    n = A.shape[0]
    lu = splu(A, permc_spec=args.method)

    L, U = lu.L, lu.U
    Lnnz, Unnz = L.nnz, U.nnz
    out = {
        "n": int(n),
        "nnzL": int(Lnnz),
        "nnzU": int(Unnz),
        "nnzF": int(Lnnz + Unnz),
        "nnzF_minus_n": int(Lnnz + Unnz - n),
        "bytesL": int(_bytes_of_sparse(L)),
        "bytesU": int(_bytes_of_sparse(U)),
        "bytesF": int(_bytes_of_sparse(L) + _bytes_of_sparse(U)),
    }
    print(json.dumps(out))

if __name__ == "__main__":
    main()
